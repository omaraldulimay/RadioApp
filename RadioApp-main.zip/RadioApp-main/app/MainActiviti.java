public class MainActiviti extends AppCompnenta{
}
